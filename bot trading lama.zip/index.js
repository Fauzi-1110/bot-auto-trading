const botApi = require("node-telegram-bot-api")
const parser = require("uzi_telegram-parser")
const fs = require("fs")
const token = "8029204461:AAEHNQI-shplmuSIc0J1loheYvsR7Jz35ss"
const Client = new botApi(token, {polling: true})
const dbSystem = require("./db-func.js")

createDBGlobal()

Client.on("message", async (m) => {
    const fc = await parser.mParsing(m)
    
    fc.message.text.splice(1, 1)
    const putus = fc.message.text.split(" ")
    const args = putus.slice(1, putus.length-1)
    const text = args.join(" ")
    const command = putus[0]
    
    switch(command){
        case "ping": {
            parser.reply(Client, m, "Pong!\nBot masih on!")
        } break
        
        case "addbot": {
            if(!text)return fc.reply(Client, m, "Masukan jumlah bot yang akan ditambah!")
            
            const jumlah = Number(args[0])
            for(let i = 0; i < jumlah; i++){
                createDBUser("bot", m)
            }
            
            parser.reply(Client, m, "Berhasil membuat bot baru sebanyak "+jumlah)
        } break
        
        case "trading": {
            
        }
    }
})

Client.on("callback_query", (q) => {
    
})


//============== 
// function
//=============
function createDBUser(type, daya){
    const readDB = JSON.parse(fs.readFileSync("./database/user.json"))
    let nama, id
    
    if(type == "bot"){
        nama = "bot-"+Object.keys(readDB).length+1
        id = Object.keys(readDB).length+1
    } else {
        nama = data.from.username || data.from.first_name || "undefined name"
        id = data.from.id
    }
    
    readDB[Object.keys(readDB).length+1] = {
        nama: nama,
        id: id
        xp: 0,
        level: 0,
            
        uang: 5000,
        perak: 0,
        emas: 0,
        platinum: 0,
        diamond: 0,
            
        balaceCoin: 0,
        roadaCoin: 0,
        flagCoin: 0,
        timenCoin: 0,
        loyaliCoin: 0,
            
        top-kaya: 0,
        jumlah-trading: 0,
    }
    
    fs.writeFileSync("./database/user.json", JSON.stringify(readDB, null, 4))
    await dbSystem.loadDB()
    return dbSystem.getUser(id)
}

function createDBGlobal(){
    const readDB = JSON.parse(fs.readFileSync("./database/global.json"))
    
    const def = {
        botOn: [],
        hargaPerak: 0,
        hargaEmas: 0,
        hargaPlatinum: 0,
        hargaDiamond: 0,
        balaceCoin: 0,
        balaceChart: [],
        roadaCoin: 0,
        roadaChart: [],
        flagCoin: 0,
        flagChart: [],
        timenCoin: 0,
        timenChart: [],
        loyaliCoin: 0
        loyaliChart: [],
    }
    
    readDB = {
        ...def,
        ...readDB
    }
    
    fs.writeFileSync("./database/global.json", JSON.stringify(readDB, null, 4))
    await dbSystem.loadDB()
}
