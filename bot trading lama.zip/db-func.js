const fs = require("fs")


class dbSystem {
    static dbUser = JSON.parse(fs.readFileSync("./database/user.json"))
    static dbGlobal = JSON.parse(fs.readFileSync("./database/global.json"))
    
    static loadDB(){
        dbSystem.dbUser = JSON.parse(fs.readFileSync("./database/user.json"))
        dbSystem.dbGlobal = JSON.parse(fs.readFileSync("./database/global.json"))
    }
    
    static getUser(id){
        if(!dbSystem.dbUser[id]) return throw new Error("Database user tidak ditemukan!")
        else return dbSystem.dbUser[id]
    }
    
    static getUserKey(id, key){
        if(!dbSystem.dbUser[id]) return throw new Error("Database user tidak ditemukan!")
        else return dbSystem.dbUser[id][key]
    }
    
    static addUser(id, key, value){
        if(!dbSystem.dbUser[id]) return throw new Error("Database user tidak ditemukan!")
        dbSystem.dbUser[id][key] += Number(value)
        fs.writeFileSync("./database/user.json", JSON.stringify(dbSystem.dbUser, null, 4))
    }
    
    static setUser(id, key, value){
        if(!dbSystem.dbUser[id]) return throw new Error("Database user tidak ditemukan!")
        dbSystem.dbUser[id][key] = value
        fs.writeFileSync("./database/user.json", JSON.stringify(dbSystem.dbUser, null, 4))
    }
    
    static getGlobalKey(key){
        return dbSystem.dbGlobal[key]
    }
    
    static addGlobalKey(key, value){
        dbSystem.dbGlobal[key] += Number(value)
        fs.writeFileSync("./database/global.json", JSON.stringify(dbSystem.dbGlobal, null, 4))
    }
    
    static setGlobalKey(key, value){
        dbSystem.dbGlobal[key] = value
        fs.writeFileSync("./database/global.json", JSON.stringify(dbSystem.dbGlobal, null, 4))
    }
}